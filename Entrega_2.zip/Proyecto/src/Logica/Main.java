package Logica;



import Persistencia.InicializadorDeClases;
import Persistencia.UsuarioPersistencia;

import java.io.FileNotFoundException;
import java.util.Scanner;


public class Main
{
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws FileNotFoundException {

        boolean salir = false;
        Galeria galeria = InicializadorDeClases.cargarGaleria();
        
        //Inventario inventario = galeeria.getInventario();
        //List<Pieza> piezas = Inventario.getPiezasBodega();

        //System.out.println(inventario);
        //System.out.println(piezas);

        while (!salir) {
            System.out.println("\nBienvenido al sistema de registro de usuarios");
            System.out.println("1. Registrarse");
            System.out.println("2. Iniciar Sesión");
            System.out.println("3. Salir");
            System.out.print("Ingrese su opción: ");
            int opcion;
            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Opción no válida. Inténtelo de nuevo.");
                continue;
            }

            switch (opcion) {
                case 1:
                	UsuarioPersistencia.registrarse();
                    break;
                case 2:
                    UsuarioPersistencia.iniciarSesion();
                    break;

                case 3:
                    salir = true;
                    System.out.println("Gracias por usar nuestro sistema. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
        scanner.close();
    }
}
    