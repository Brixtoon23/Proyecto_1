package Logica;

import java.util.List;

public class Fotografia extends Pieza

{
	private String resolucion;
	private String tamanioGiga;
	
	
	public Fotografia(String titulo, int anioCreacion, String lugarCreacion, List<String> autor, boolean disponible,
			int tiempoConsignacion, boolean subasta, List<Integer> valores, String propietario, boolean bodega,
			String tipo, String resolucion, String tamanioGiga) {
		super(titulo, anioCreacion, lugarCreacion, autor, disponible, tiempoConsignacion, subasta, valores, propietario,
				bodega, tipo);
		this.resolucion = resolucion;
		this.tamanioGiga = tamanioGiga;
	}

	public String getResolucion() {
		return resolucion;
	}

	public String getTamanioGiga() {
		return tamanioGiga;
	}
	

	

	
	

}
