package Persistencia;
import java.io.*;
import org.json.JSONArray;
import org.json.JSONObject;

import Logica.Administrador;
import Logica.Escultura;
import Logica.Fotografia;
import Logica.Pintura;
import Logica.Video;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class PiezasPersistencia {
	
	static JSONObject baseDeDatosJSON = leerBaseDeDatos();

	static List<JSONObject> piezas = obtenerPiezasDesdeJSON(baseDeDatosJSON.getJSONArray("piezas"));
	private static Scanner scanner = new Scanner(System.in);
	
	
	public static void registrarPieza() {   

        System.out.print("Ingrese el título: ");
        String titulo = scanner.nextLine();
        
        
        System.out.print("Ingrese su año de creación: ");
        int anioCreacion = Integer.parseInt(scanner.nextLine());
        
        System.out.print("Ingrese lugar de creación: ");
        String lugarCreacion = scanner.nextLine();
        
        System.out.print("Ingrese autor/es separados por ;: ");
        String autorCadena = scanner.nextLine();
        List<String> autores = new ArrayList<>();
        String[] autoresArray = autorCadena.split(";");
        for (String autor : autoresArray) {
            autores.add(autor.trim()); 
        }
        
        System.out.print("¿Se encuentra disponible? (true/false): ");
        boolean disponible = Boolean.parseBoolean(scanner.nextLine());
        
        System.out.print("Tiempo de consignación (-1 si no aplica): ");
        int tiempoConsignacion = Integer.parseInt(scanner.nextLine());
        
        System.out.print("¿Se encuentra en subasta? (true/false): ");
        boolean subasta = Boolean.parseBoolean(scanner.nextLine());
        
        System.out.print("Ingrese los valores separados por ;: ");
        String valoresCadena = scanner.nextLine();
        String[] partes = valoresCadena.split(";");


        int[] valores = new int[partes.length];
        ArrayList<Integer> valoresList = new ArrayList<>();

     
        for (int i = 0; i < partes.length; i++) {
            valores[i] = Integer.parseInt(partes[i]);
            valoresList.add(Integer.parseInt(partes[i]));
        }
        
        System.out.print("Ingrese propietario: ");
        String propietario = scanner.nextLine();
        
        System.out.print("¿Se encuentra en bodega? (true/false): ");
        boolean bodega = Boolean.parseBoolean(scanner.nextLine());
        
        System.out.print("Ingrese el tipo (pintura/escultura/video/fotografia): ");
        String tipo = scanner.nextLine();
        
        // Crear el objeto JSON para la nueva pieza
        JSONObject piezaJSON = new JSONObject();
        piezaJSON.put("titulo", titulo);
        piezaJSON.put("anioCreacion", anioCreacion);
        piezaJSON.put("lugarCreacion", lugarCreacion);
        piezaJSON.put("autores", new JSONArray(autores)); // Usar un JSONArray para los autores
        piezaJSON.put("disponible", disponible);
        piezaJSON.put("tiempoConsignacion", tiempoConsignacion);
        piezaJSON.put("subasta", subasta);
        piezaJSON.put("valores", new JSONArray(valores)); // Usar un JSONArray para los valores
        piezaJSON.put("propietario", propietario);
        piezaJSON.put("bodega", bodega);
        piezaJSON.put("tipo", tipo);

        // Crear el objeto JSON para los valores especiales según el tipo
        JSONObject valoresEspecialesJSON = new JSONObject();
        switch (tipo) {
            case "pintura":
            	System.out.print("Ingrese el alto: ");
                int alto = Integer.parseInt(scanner.nextLine());
                valoresEspecialesJSON.put("alto", alto);
                
                System.out.print("Ingrese el ancho: ");
                int ancho = Integer.parseInt(scanner.nextLine());
                valoresEspecialesJSON.put("ancho", ancho);
                
                System.out.print("Ingrese el peso: ");
                int peso = Integer.parseInt(scanner.nextLine());
                valoresEspecialesJSON.put("peso", peso);
                
                System.out.print("Ingrese la técnica: ");
                String tecnica = scanner.nextLine();
                valoresEspecialesJSON.put("tecnica", tecnica);
                Pintura pintura = new Pintura(titulo, anioCreacion, lugarCreacion, autores, disponible, tiempoConsignacion, subasta, valoresList, propietario, bodega, tipo, alto, ancho, peso, tecnica);
                Administrador.ingresarPieza(pintura);
                break;
                
            case "fotografia":
            	System.out.print("Ingrese la resolución: ");
                String resolucion = scanner.nextLine();
                valoresEspecialesJSON.put("resolucion", resolucion);
                
                System.out.print("Ingrese el tamaño en gigas: ");
                String tamanioGiga = scanner.nextLine();
                valoresEspecialesJSON.put("tamanioGiga", tamanioGiga);
                Fotografia fotografia= new Fotografia(titulo, anioCreacion, lugarCreacion, autores, disponible, tiempoConsignacion, subasta, valoresList, propietario, bodega, tipo, resolucion, tamanioGiga);
                Administrador.ingresarPieza(fotografia);
                break;
                
            case "escultura":
            	System.out.print("Ingrese el alto: ");
                int alto1 = Integer.parseInt(scanner.nextLine());
                valoresEspecialesJSON.put("alto", alto1);
                
                System.out.print("Ingrese el ancho: ");
                int ancho1 = Integer.parseInt(scanner.nextLine());
                valoresEspecialesJSON.put("ancho", ancho1);
                
                System.out.print("Ingrese la profundidad: ");
                int profundidad = Integer.parseInt(scanner.nextLine());
                valoresEspecialesJSON.put("profundidad", profundidad);
                
                System.out.print("Ingrese el peso: ");
                int peso1 = Integer.parseInt(scanner.nextLine());
                valoresEspecialesJSON.put("peso", peso1);
                
                System.out.print("¿Necesita electricidad? (true/false): ");
                boolean electricidad = Boolean.parseBoolean(scanner.nextLine());
                valoresEspecialesJSON.put("electricidad", electricidad);

                Escultura escultura= new Escultura(titulo, anioCreacion, lugarCreacion, autores, disponible, tiempoConsignacion, subasta, valoresList, propietario, bodega, tipo, alto1, ancho1, profundidad, peso1, electricidad);
                Administrador.ingresarPieza(escultura);
                break;
                
            case "video":
            	System.out.print("Ingrese la duración en minutos: ");
                int duracion = Integer.parseInt(scanner.nextLine());
                valoresEspecialesJSON.put("duracion", duracion);
                
                System.out.print("Ingrese el tamaño en gigas: ");
                int tamanioGiga1 = Integer.parseInt(scanner.nextLine());
                valoresEspecialesJSON.put("tamanioGiga", tamanioGiga1);
                
                System.out.print("Ingrese la resolución: ");
                String resolucion1 = scanner.nextLine();
                valoresEspecialesJSON.put("resolucion", resolucion1);
                Video video= new Video(titulo, anioCreacion, lugarCreacion, autores, disponible, tiempoConsignacion, subasta, valoresList, propietario, bodega, tipo, duracion, tamanioGiga1, resolucion1);

                Administrador.ingresarPieza(video);
                break;
                
            default:
                System.out.println("Tipo no reconocido. Los valores especiales no se guardarán.");
        }
        
        piezaJSON.put("valoresEspeciales", valoresEspecialesJSON);

        // Agregar la nueva pieza al arreglo de piezas
        piezas.add(piezaJSON);

        // Guardar la base de datos actualizada
        baseDeDatosJSON.put("piezas", new JSONArray(piezas)); // Actualizar el arreglo de piezas en el JSON
        guardarBaseDeDatos(baseDeDatosJSON);

        System.out.println("Registro exitoso.");
        scanner.close();
    }

    private static List<JSONObject> obtenerPiezasDesdeJSON(JSONArray piezasArray) {
        List<JSONObject> listaPiezas = new ArrayList<>();
        for (int i = 0; i < piezasArray.length(); i++) {
            listaPiezas.add(piezasArray.getJSONObject(i));
        }
        return listaPiezas;
    }

    private static JSONObject leerBaseDeDatos() {
        try {
            // Utilizamos la misma ruta relativa que en guardarBaseDeDatos
            File archivo = new File("Archivos/base_de_datos_piezas.json");
            Scanner scanner = new Scanner(archivo);
            StringBuilder jsonText = new StringBuilder();
            while (scanner.hasNextLine()) {
                jsonText.append(scanner.nextLine());
            }
            scanner.close();
            return new JSONObject(jsonText.toString());
        } catch (FileNotFoundException e) {
            // Si el archivo no existe, se devuelve un JSON con un arreglo de piezas vacío
            return new JSONObject().put("piezas", new JSONArray());
        }
    }

    private static void guardarBaseDeDatos(JSONObject baseDeDatosJSON) {
        try (FileWriter file = new FileWriter("Archivos/base_de_datos_piezas.json")) {
            file.write(baseDeDatosJSON.toString(4));
            System.out.println("Base de datos actualizada y guardada.");
        } catch (IOException e) {
            System.out.println("Error al guardar la base de datos.");
            e.printStackTrace();
        }
    }

    // Método para obtener la lista de piezas desde un JSONArray
}