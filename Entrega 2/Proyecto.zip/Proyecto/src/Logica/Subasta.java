package Logica;

import java.util.ArrayList;
import java.util.List;

public class Subasta
{
    private List<Oferta> listaOfertas;
    private List<Pieza> listaPiezasSubasta;

    public Subasta(List<Pieza> listaPiezasSubasta) {
        this.listaOfertas = new ArrayList<>(); 
        this.listaPiezasSubasta =  new ArrayList<>();
    }

   
    public void agregarPieza() 
    {
    	List<Pieza>  piezasBodega = Inventario.getPiezasBodega();
    	List<Pieza>  piezasExhibidas = Inventario.getPiezasExhibidad();
    	for (Pieza pieza: piezasBodega)
    	{
    		if(pieza.isSubasta()== true)
    		{
    			listaPiezasSubasta.add(pieza);
    		}
    	}
    	
    	for (Pieza pieza: piezasExhibidas)
    	{
    		if(pieza.isSubasta()== true)
    		{
    			listaPiezasSubasta.add(pieza);
    		}
    	}
    }

   
    public void agregarOferta(Oferta oferta) {
        listaOfertas.add(oferta);
    }

    
    public List<Oferta> getOfertas() {
        return listaOfertas;
    }

   
    public List<Pieza> getPiezasSubastadas() {
        return listaPiezasSubasta;
    }
    

    
}
