package Logica;

public class Compra 
{
	private boolean aceptada;
	private Comprador comprador;
	private int precio;
	private String metodopago;
	private Pieza pieza;
	public Compra(boolean aceptada, Comprador comprador, int precio, String metodoPago2, Pieza pieza) {
		
		this.aceptada = aceptada;
		this.comprador = comprador;
		this.precio = precio;
		this.metodopago = metodoPago2;
		this.pieza = pieza;
	}
	public boolean isAceptada() {
		return aceptada;
	}
	public Comprador getComprador() {
		return comprador;
	}
	public int getPrecio() {
		return precio;
	}
	public String getMetodopago() {
		return metodopago;
	}
	public Pieza getPieza() {
		return pieza;
	}
	
	

}
