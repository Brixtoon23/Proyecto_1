package Logica;

import java.util.Collection;
import java.util.List;

public class Video extends Pieza
{
	private int duracion;
	private int tamanioGiga;
	private String resolucion;

	public Video(String titulo, int anioCreacion, String lugarCreacion, List<String> autor, boolean disponoble,
			int tiempoConsignacion, boolean subasta, List<Integer> valores, Propietario propietario, boolean bodega,
			String tipo,int duracion, int tamanioGiga,String resolucion) 
	{
		super(titulo, anioCreacion, lugarCreacion, autor, disponoble, tiempoConsignacion, subasta, valores, propietario,
				bodega,tipo);
		this.duracion = duracion;
		this.tamanioGiga = tamanioGiga;
		this.resolucion = resolucion;
		
		
	}

	public int getDuracion() {
		return duracion;
	}

	public int getTamanioGiga() {
		return tamanioGiga;
	}

	public String getResolucion() {
		return resolucion;
	}

	public boolean isDisponible() {
		// TODO Auto-generated method stub
		return disponoble;
	}

	
	

}
