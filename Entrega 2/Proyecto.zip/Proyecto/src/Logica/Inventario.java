package Logica;

import java.util.List;

public class Inventario {
	private Galeria galeria;
	private  List<Usuario> usuarios;
	private  static List<Pieza> piezasBodega;
	private static List<Pieza> piezasExhibidad;
	
	
	public Inventario(Galeria galeria, List<Usuario> usuarios, List<Pieza> piezasBodega, List<Pieza> piezasExhibidad) {
	
		this.galeria = galeria;
		this.usuarios = usuarios;
		this.piezasBodega = piezasBodega;
		this.piezasExhibidad = piezasExhibidad;
	}


	public Galeria getGaleria() {
		return galeria;
	}


	public List<Usuario> getUsuarios() {
		return usuarios;
	}


	public static List<Pieza> getPiezasBodega() {
		return piezasBodega;
	}


	public static List<Pieza> getPiezasExhibidad() {
		return piezasExhibidad;
	}
	
	
	

}
