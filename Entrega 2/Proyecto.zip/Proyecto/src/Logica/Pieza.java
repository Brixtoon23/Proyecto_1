package Logica;

import java.util.List;

public  class Pieza
{
	
	protected String titulo;
	protected int anioCreacion;
	protected String  lugarCreacion;
	protected List<String> autor;
	protected  boolean  disponoble;
	protected int tiempoConsignacion;
	protected  boolean subasta;
	protected List<Integer> valores;
	protected Propietario propietario;
	protected boolean bodega;
	protected String tipo;
	public Pieza(String titulo, int anioCreacion, String lugarCreacion, List<String> autor, boolean disponoble,
			int tiempoConsignacion, boolean subasta, List<Integer> valores, Propietario propietario, 
			boolean bodega,String tipo) 
	{
		super();
		this.titulo = titulo;
		this.anioCreacion = anioCreacion;
		this.lugarCreacion = lugarCreacion;
		this.autor = autor;
		this.disponoble = disponoble;
		this.tiempoConsignacion = tiempoConsignacion;
		this.subasta = subasta;
		this.valores = valores;
		this.propietario = propietario;
		this.bodega = bodega;
		this.tipo = tipo;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public int getAnioCreacion() {
		return anioCreacion;
	}
	public void setAnioCreacion(int anioCreacion) {
		this.anioCreacion = anioCreacion;
	}
	public String getLugarCreacion() {
		return lugarCreacion;
	}
	public void setLugarCreacion(String lugarCreacion) {
		this.lugarCreacion = lugarCreacion;
	}
	public List<String> getAutor() {
		return autor;
	}
	public void setAutor(List<String> autor) {
		this.autor = autor;
	}
	public boolean isDisponoble() {
		return disponoble;
	}
	public void setDisponoble(boolean disponoble) {
		this.disponoble = disponoble;
	}
	public int getTiempoConsignacion() {
		return tiempoConsignacion;
	}
	public void setTiempoConsignacion(int tiempoConsignacion) {
		this.tiempoConsignacion = tiempoConsignacion;
	}
	public boolean isSubasta() {
		return subasta;
	}
	public void setSubasta(boolean subasta) {
		this.subasta = subasta;
	}
	public List<Integer> getValores() {
		return valores;
	}
	public void setValores(List<Integer> valores) {
		this.valores = valores;
	}
	public Propietario getPropietario() {
		return propietario;
	}
	public void setPropietario(Propietario propietario) {
		this.propietario = propietario;
	}
	public boolean isBodega() {
		return bodega;
	}
	public void setBodega(boolean bodega) {
		this.bodega = bodega;
	}

	public String getTipo() {
		return tipo;
	}
	public void setPropietario(String tipo) {
		this.tipo = tipo;
	}
	
	
	
	
	
	
	
	
}
