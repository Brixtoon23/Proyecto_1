package Logica;


import java.util.List;

public class Administrador extends Usuario
{
	

	public Administrador(String login, String nombre, String password, String rol, String telefono, boolean verificado) {
		super(login, nombre, password, rol, telefono, verificado);
		
	}
	
	public void ingresarPieza(Pieza pieza) {
		
		if(pieza.isBodega()==true)
		{
			   Inventario.getPiezasBodega().add(pieza);
			  
		     
		}
		else
		{
			 Inventario.getPiezasExhibidad().add(pieza);
		}
		
		
	}
		
	
	public void verificarCliente(Comprador cliente)
	{
		if (cliente.isMora()==false)
		{
			cliente.setVerificado(true);

	        float estadoCuenta = cliente.getEstadoCuenta();

	        if (estadoCuenta < 200000) 
	        {
	            cliente.setMaxCompras(150000);
	        } 
	        
	        else if (estadoCuenta >= 200000 && estadoCuenta < 900000) 
	        {
	            cliente.setMaxCompras(800000);
	        } 
	        
	        else if (estadoCuenta >= 900000 && estadoCuenta < 2000000)
	        {
	            cliente.setMaxCompras(1900000);
	        }
		}
		
		else
		{
			cliente.setVerificado(false);
		}
		
	}
		
	
	public void verificarOperador(Operador operador)
	{
		if (operador.password == "Galeria")
			operador.setVerificado(true);
		else
		{
			operador.setVerificado(false);
		}
		
   
		
	}
	public void verificarCajero(Cajero cajero)
	{
		if (cajero.password == "Transferencia")
			cajero.setVerificado(true);
		else
		{
			cajero.setVerificado(false);
		}
	}
	
	
		
	public void aprobarVentaSubasta(Operador operador )
	{
		List<Oferta> mejoresOfertas= Operador.mejoresOfertas(operador.getSubastas());
		
		for (Oferta oferta: mejoresOfertas)
		{
			
			Comprador comprador= oferta.getComprador();
			if (comprador.isMora()== true)
				oferta.getPiezaSubastada().setDisponoble(true);
			else if (comprador.getEstadoCuenta()< oferta.getValorOfertado())
			{
				oferta.getPiezaSubastada().setDisponoble(true);
			
			}
			else if (oferta.getValorOfertado() > comprador.getMaxCompras())
					{
				         oferta.getPiezaSubastada().setDisponoble(true);
					}
			else
			{
				Cajero.registrarCompraSubasta(oferta);
			}
		}
	}
	
	public void aprobarVentaPrecioFijo(Comprador comprador,Pieza pieza ) 
	{
		float cuenta = comprador.getEstadoCuenta();
		List<Integer> valores = pieza.getValores();
		int precioFijo = valores.get(0);
		if (precioFijo <= cuenta)
		{
			Cajero.registrarCompraPrecioFijo(comprador,pieza );
			
		}
		
		
		
		
	}
}




