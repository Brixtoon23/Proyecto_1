package Logica;

import java.util.List;

public class Propietario extends Usuario
{
	
	private List<Pieza> piezasActuales;
	private List<Pieza> historialPiezas;
	
	public Propietario(String login, String nombre, String password, String rol, String telefono, boolean verificado,
			List<Pieza> piezasActuales, List<Pieza> historialPiezas) 
	{
		super(login, nombre, password, rol, telefono, verificado);
		this.piezasActuales = piezasActuales;
		this.historialPiezas = historialPiezas;
	}

	public List<Pieza> getPiezasActuales() {
		return piezasActuales;
	}

	public void setPiezasActuales(List<Pieza> piezasActuales) {
		this.piezasActuales = piezasActuales;
	}

	public List<Pieza> getHistorialPiezas() {
		return historialPiezas;
	}

	public void setHistorialPiezas(List<Pieza> historialPiezas) {
		this.historialPiezas = historialPiezas;
	}
	
	
	
	
	

}
