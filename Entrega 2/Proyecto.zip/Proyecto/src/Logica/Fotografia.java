package Logica;

import java.util.List;

public class Fotografia extends Pieza

{
	private String resolucion;
	private String tamanioGiga;
	
	public Fotografia(String titulo, int anioCreacion, String lugarCreacion, List<String> autor, boolean disponoble,
			int tiempoConsignacion, boolean subasta, List<Integer> valores, Propietario propietario, boolean bodega,
			String tipo, String resolucion,String tamanioGiga) 
	{
		super(titulo, anioCreacion, lugarCreacion, autor, disponoble, tiempoConsignacion, subasta, 
				valores, propietario,bodega,tipo);
		this.tamanioGiga = tamanioGiga;
		this.resolucion = resolucion;
		


	}

	public String getResolucion() {
		return resolucion;
	}

	public String getTamanioGiga() {
		return tamanioGiga;
	}
	

	

	
	

}
