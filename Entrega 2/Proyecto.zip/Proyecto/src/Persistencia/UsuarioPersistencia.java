package Persistencia;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

import Logica.Galeria;
import Logica.Inventario;

public class UsuarioPersistencia {

    private static Scanner scanner = new Scanner(System.in);

    public static void registrarse() {
        System.out.println("\n--- Registrarse ---");
        System.out.print("Ingrese su login: ");
        String login = scanner.nextLine();

        // Verificar si el usuario ya existe
        JSONObject baseDeDatosJSON = leerBaseDeDatos();
        JSONArray usuariosArray = baseDeDatosJSON.getJSONArray("usuarios");
        for (int i = 0; i < usuariosArray.length(); i++) {
            JSONObject usuario = usuariosArray.getJSONObject(i);
            if (usuario.getString("login").equals(login)) {
                System.out.println("Ya existe un usuario con ese login. Inténtelo de nuevo.");
                return;
            }
        }

        System.out.print("Ingrese su nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese su contraseña: ");
        String contraseña = scanner.nextLine();
        System.out.print("Ingrese su rol (cajero / administrador / comprador / propietario): ");
        String rol = scanner.nextLine();
        System.out.print("Ingrese su número de teléfono: ");
        String telefono = scanner.nextLine();

        JSONObject usuarioJSON = new JSONObject();
        usuarioJSON.put("login", login);
        usuarioJSON.put("nombre", nombre);
        usuarioJSON.put("contraseña", contraseña);
        usuarioJSON.put("rol", rol);
        usuarioJSON.put("telefono", telefono);

        JSONObject valoresEspecialesJSON = new JSONObject();
        switch (rol) {
            case "cajero":
                valoresEspecialesJSON.put("comprasRegistradas", new JSONArray());
                break;
            case "administrador":
                valoresEspecialesJSON.put("soyAdmin", true);
                break;
            case "comprador":
                valoresEspecialesJSON.put("estadoCuenta", 0.0);
                valoresEspecialesJSON.put("historialCompras", new JSONArray());
                valoresEspecialesJSON.put("maxCompras", 0.0);
                valoresEspecialesJSON.put("seguridadFinanciera", false);
                valoresEspecialesJSON.put("mora", false);
                valoresEspecialesJSON.put("piezasCompradas", new JSONArray());
                valoresEspecialesJSON.put("metodoPago", "");
                break;
            case "propietario":
                valoresEspecialesJSON.put("piezasActuales", new JSONArray());
                valoresEspecialesJSON.put("historialPiezas", new JSONArray());
                break;
            default:
                System.out.println("Rol no reconocido. Los valores especiales no se guardarán.");
        }

        usuarioJSON.put("valores_especiales", valoresEspecialesJSON);

        usuariosArray.put(usuarioJSON);

        guardarBaseDeDatos(baseDeDatosJSON);

        System.out.println("Registro exitoso.");
    }

    private static JSONObject leerBaseDeDatos() {
        try {
            Scanner scanner = new Scanner(new File("Archivos/base_de_datos_usuarios.json"));
            StringBuilder jsonText = new StringBuilder();
            while (scanner.hasNextLine()) {
                jsonText.append(scanner.nextLine());
            }
            scanner.close();
            return new JSONObject(jsonText.toString());
        } catch (FileNotFoundException e) {
            // Si el archivo no existe, se devuelve un JSON vacío
            return new JSONObject().put("usuarios", new JSONArray());
        }
    }

    private static void guardarBaseDeDatos(JSONObject baseDeDatosJSON) {
        try (FileWriter file = new FileWriter("Archivos/base_de_datos_usuarios.json")) {
            file.write(baseDeDatosJSON.toString(4));
            System.out.println("Base de datos actualizada y guardada.");
        } catch (IOException e) {
            System.out.println("Error al guardar la base de datos.");
            e.printStackTrace();
        }
    }

    public static void iniciarSesion() {
        System.out.println("\n--- Iniciar Sesión ---");
        System.out.print("Ingrese su login: ");
        String login = scanner.nextLine();
        System.out.print("Ingrese su contraseña: ");
        String contraseña = scanner.nextLine();

        JSONObject baseDeDatosJSON = leerBaseDeDatos();
        JSONArray usuariosArray = baseDeDatosJSON.getJSONArray("usuarios");
        boolean usuarioEncontrado = false;

        for (int i = 0; i < usuariosArray.length(); i++) {
            JSONObject usuario = usuariosArray.getJSONObject(i);
            if (usuario.getString("login").equals(login) && usuario.getString("contraseña").equals(contraseña)) {
                usuarioEncontrado = true;
                String rol = usuario.getString("rol");
                System.out.println("Inicio de sesión exitoso como " + rol);

                switch (rol) {
                    case "cajero":
                        menuCajero();
                        break;
                    case "administrador":
                        menuAdministrador();
                        break;
                    case "comprador":
                        menuComprador();
                        break;
                    case "propietario":
                        menuPropietario();
                        break;
                    case "operador":
                        menuOperador();
                        break;
                    default:
                        System.out.println("Rol no reconocido. No se puede abrir el menú.");
                }
                break;
            }
        }

        if (!usuarioEncontrado) {
            System.out.println("Login o contraseña incorrectos. Inténtelo de nuevo.");
        }
    }

    private static void menuCajero() {
        boolean salir = false;

        while (!salir) {
            System.out.println("\nBienvenido al menu cajero");
            System.out.println("1. Registrar_Venta");
            System.out.println("2. Salir");
            System.out.print("Ingrese su opción: ");
            int opcion;
            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Opción no válida. Inténtelo de nuevo.");
                continue;
            }

            switch (opcion) {
                case 1:
                    UsuarioPersistencia.registrarse();
                    break;
                case 2:
                    salir = true;
                    System.out.println("Gracias por usar nuestro sistema. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
    }

    private static void menuAdministrador() {
        boolean salir = false;

        while (!salir) {
            System.out.println("\nBienvenido al menu administrador");
            System.out.println("1. Cargar_Pieza");
            System.out.println("2. Verificar_Usuarios");
            System.out.println("3. Ver_Galeria");
            System.out.println("4. Salir");
            System.out.print("Ingrese su opción: ");
            int opcion;
            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Opción no válida. Inténtelo de nuevo.");
                continue;
            }

            switch (opcion) {
                case 1:
                    PiezasPersistencia.registrarPieza();
                    break;
                case 2:
                    UsuarioPersistencia.iniciarSesion();
                    break;
                case 3:
                    
                    break;
                case 4:
                    salir = true;
                    System.out.println("Gracias por usar nuestro sistema. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
    }

    private static void menuComprador() {
        boolean salir = false;

        while (!salir) {
            System.out.println("\nBienvenido al menu comprador");
            System.out.println("1. Ver Piezas Subasta");
            System.out.println("2. Ver piezas PrecioFijo");
            System.out.println("3. Salir");
            System.out.print("Ingrese su opción: ");
            int opcion;
            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Opción no válida. Inténtelo de nuevo.");
                continue;
            }

            switch (opcion) {
                case 1:
                    ImprimirJSON.ImprimirPiezas(opcion);;
                    break;
                case 2:
                    ImprimirJSON.ImprimirPiezas(opcion);;
                    break;
                case 3:
                    salir = true;
                    System.out.println("Gracias por usar nuestro sistema. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
    }

    private static void menuPropietario() {
        boolean salir = false;

        while (!salir) {
            System.out.println("\nBienvenido al menu Propietario");
            System.out.println("1. Cargar el historial");
            System.out.println("2. Ver estado piezas");
            System.out.println("3. Salir");
            System.out.print("Ingrese su opción: ");
            int opcion;
            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Opción no válida. Inténtelo de nuevo.");
                continue;
            }

            switch (opcion) {
                case 1:
                    UsuarioPersistencia.registrarse();
                    break;
                case 2:
                    UsuarioPersistencia.iniciarSesion();
                    break;
                case 3:
                    salir = true;
                    System.out.println("Gracias por usar nuestro sistema. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
    }
    private static void menuOperador() {
        boolean salir = false;

        while (!salir) {
            System.out.println("\nBienvenido al menu cajero");
            System.out.println("1. Registrar_Pujas");
            System.out.println("2. Salir");
            System.out.print("Ingrese su opción: ");
            int opcion;
            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Opción no válida. Inténtelo de nuevo.");
                continue;
            }

            switch (opcion) {
                case 1:
                    UsuarioPersistencia.registrarse();
                    break;
                case 2:
                    salir = true;
                    System.out.println("Gracias por usar nuestro sistema. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
    }
    
}


